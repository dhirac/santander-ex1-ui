
import React, { Component } from 'react';
import Header from './components/header';

import Body from './components/body';
import Footer from './components/footer';

export default class Landing extends Component {

    constructor(props){
        super(props);
        
    }

  render() {
    return (
    <>

     
       <Body/>

       <Footer/>

    </>
    );
  }
}
