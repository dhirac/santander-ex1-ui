import React from 'react'

import Landing from './landing'
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
     <Landing/>
  );
}

export default App;
