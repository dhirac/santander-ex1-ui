
import React, { Component } from 'react';
import Branding from '../assest/santander.jpg'
import TopBanner from '../assest/mbanner.jpg'

import {Button,Container,Row,Col } from 'react-bootstrap';

export default class Logo extends Component {
  render() {
    return (
     
 
<>

<Container fluid>
    <Row fluid>

        <Col style={{ position: "absolute", bottom: "0px", height:15, flexShrink:'initial'}} >
        
        
        </Col>
        
    </Row>
</Container>
       
     </>
    );
  }
}
