
import React, { Component } from 'react';
import TopBanner from '../assest/mbanner.jpg'

import { Button,Container,Row,Col } from 'react-bootstrap';

export default class Logo extends Component {
  render() {
    return (
     
 
<>
<Container fluid>
          <Row style={{marginTop:"2px"}}>

           

              <Col style={{ backgroundImage: `url(${TopBanner})` , backgroundRepeat:'repeat-x', height:60,margin:0, padding:0}}></Col>

             {/**<img src={TopBanner}  alt="Logo" style={{ width:600,resizeMode:"repeat"}} />  */} 
            
           
         
          </Row>
</Container>

<Container fluid>
          <Row style={{backgroundColor:'#EA2025',height:"150px",marginTop:"2px"}}>
          <Col   xs={6} md={4}></Col>
          <Col  xs={6} md={4}>  
          
           {/* <img src={Branding}  alt="Logo" style={{width:"200px", }} />  */}

             <h1 style={{fontSize:70,color:'white',marginTop:'20px',textAlign:'center',marginBottom:0,paddingBottom:0}}>SANTANDAR</h1>
             <h2 style={{marginTop:'0px',color:'white',textAlign:'center',fontSize:'15px'}}>Search the entire movie industry with us</h2>
          
          </Col>
          <Col  xs={6} md={4}></Col>
       
          </Row>
          <Row fluid>
           
              <Col style={{backgroundColor:'#cccccc',height:'10px'}}></Col>
           
          </Row>
</Container>
       
     </>
    );
  }
}
